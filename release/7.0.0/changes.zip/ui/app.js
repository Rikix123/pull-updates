'use strict';
// Keyboard actions stay immediate; only pointer-opened dialogs use the optional entrance.
document.documentElement.dataset.input='keyboard';
document.addEventListener('keydown',()=>{document.documentElement.dataset.input='keyboard';},true);
document.addEventListener('pointerdown',()=>{document.documentElement.dataset.input='pointer';},true);
const $=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state={profiles:[],folders:[],tabs:[],proxies:[],proxyFolders:[],extensions:[],groups:[],templates:[],savedFilters:[],launchDelayMs:250,proxyCheckUrl:'https://www.ticketmaster.com/',canGoBack:false,canGoForward:false,canReload:false},selected=new Set(),folder='all',selectedTagFilter='all',proxyStateFilter='all',runStateFilter='all',extensionFilter='all',seq=0,toastTimer,diagnostics=null;
let selectedProxyFolder='all',proxyAssignFilter='all',proxySearchQuery='',showProxyImport=false,selectedProxies=new Set();
let dragLaunchActive=false;
const dragLaunchSet=new Set();
const proxyDiagnostics=new Map();
const pending=new Map();
let lastTabSignature='';
let stableTabIds=[],tabOrderSyncInFlight=false,tabOrderSyncFailedKey='',draggedTabId=null,tabRenderPending=false,lastRevealedTab='';
const pendingLaunchBatches=[];
const profileRowMarkup=new Map();

// Preserve unchanged rows when the host emits frequent state updates. The table
// uses delegated events, so retaining rows does not change the action contract.
function updateProfileRows(entries){
  const body=$('rows'), previous=[...body.children];
  const changed=entries.reduce((count,entry)=>count+(profileRowMarkup.get(entry.id)!==entry.html?1:0),0);
  if(!previous.length || Math.abs(previous.length-entries.length)>previous.length/2 || changed>Math.max(24,entries.length/3)){
    body.innerHTML=entries.map(entry=>entry.html).join('');
    profileRowMarkup.clear();
    entries.forEach(entry=>profileRowMarkup.set(entry.id,entry.html));
    return;
  }
  const existing=new Map(previous.map(row=>[row.dataset.rowId,row]));
  const order=previous.map(row=>row.dataset.rowId), wanted=new Set();
  const scratch=document.createElement('tbody');
  entries.forEach((entry,index)=>{
    wanted.add(entry.id);
    let row=existing.get(entry.id);
    if(!row || profileRowMarkup.get(entry.id)!==entry.html){
      scratch.innerHTML=entry.html;
      const replacement=scratch.firstElementChild;
      if(row)row.replaceWith(replacement);
      row=replacement;
      profileRowMarkup.set(entry.id,entry.html);
    }
    if(order[index]!==entry.id){
      body.insertBefore(row,body.children[index]||null);
      const oldIndex=order.indexOf(entry.id,index+1);
      if(oldIndex!==-1)order.splice(oldIndex,1);
      order.splice(index,0,entry.id);
    }
  });
  existing.forEach((row,id)=>{if(!wanted.has(id)){row.remove();profileRowMarkup.delete(id);}});
}

/* ─── STARTUP INTRO OVERLAY ─── */
(function setupIntro(){
  const intro=$('introOverlay');
  if(!intro)return;
  const dismiss=()=>{
    intro.classList.add('fade-out');
    setTimeout(()=>{try{intro.remove();}catch(e){}},600);
  };
  intro.onclick=dismiss;
  setTimeout(dismiss,1200);
})();

function call(action,args={},timeout=60000){return new Promise((resolve,reject)=>{
  const id=String(++seq),timer=setTimeout(()=>{pending.delete(id);reject(Error('This operation timed out. Please try again.'));},timeout);
  pending.set(id,{resolve,reject,timer});
  try{chrome.webview.postMessage({id,action,args});}catch(error){clearTimeout(timer);pending.delete(id);reject(error);}
});}
async function run(action,args={}){
  const batch=action==='launch'&&Array.isArray(args.ids)?{ids:[...args.ids]}:null;
  if(batch)pendingLaunchBatches.push(batch);
  try{return await call(action,args);}catch(e){toast(e.message);}
  finally{if(batch){const index=pendingLaunchBatches.indexOf(batch);if(index!==-1)pendingLaunchBatches.splice(index,1);}}
}
function toast(text){$('toastText').textContent=text;$('toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('visible'),8000);}

$('toastClose').onclick=()=>{$('toast').classList.remove('visible');clearTimeout(toastTimer);};
chrome.webview.addEventListener('message',({data})=>{
  if(data.type==='openCommands'){window.dispatchEvent(new Event('pull:commands'));return;}
  if(data.type==='state'){state=data.state;$('bootStatus').classList.add('hidden');render();return;}
  if(data.type==='notice'){toast(data.text);return;}
  if(data.type==='focusAddress'){$('address').focus();$('address').select();return;}
  const item=pending.get(data.id);
  if(item){clearTimeout(item.timer);pending.delete(data.id);if(data.error)item.reject(Error(data.error));else item.resolve(data.result);}
});

const opts=(items,value,empty)=>(empty?`<option value="">${esc(empty)}</option>`:'')+items.map(x=>`<option value="${esc(x.id)}" ${x.id===value?'selected':''}>${esc(x.name)}</option>`).join('');

function listProfiles(){
  const q=$('search').value.toLowerCase();
  return state.profiles.filter(p=>{
    const matchFolder=folder==='all'||p.folder===folder;
    const matchTag=selectedTagFilter==='all'||(p.tags&&p.tags.includes(selectedTagFilter));
    const matchSearch=p.name.toLowerCase().includes(q)||(p.tags&&p.tags.some(t=>t.toLowerCase().includes(q)))||(p.notes||'').toLowerCase().includes(q);
    const matchProxy=proxyStateFilter==='all'||(proxyStateFilter==='assigned'?Boolean(p.proxyId):!p.proxyId);
    const matchRun=runStateFilter==='all'||(p.status||'').toLowerCase()===runStateFilter;
    const matchExtension=extensionFilter==='all'||(p.extensions||[]).includes(extensionFilter);
    return matchFolder&&matchTag&&matchSearch&&matchProxy&&matchRun&&matchExtension;
  });
}

function updateLaunchButtons(visible=listProfiles()){
  const visibleSelected=visible.filter(p=>selected.has(p.id)).length;
  const hidden=selected.size-visibleSelected, hasSel=visibleSelected>0;
  $('selectionSummary').textContent=selected.size
    ? `${visibleSelected} selected${hidden?` · ${hidden} hidden`:''}`
    : `${visible.length} profiles`;
  $('launch').disabled=!hasSel;
  $('bulkTags').disabled=!hasSel;
  $('bulkProxy').disabled=!hasSel;
  $('delete').disabled=!hasSel;
  $('clearProfileSelection').disabled=!selected.size;
}

function updateNavState(){
  const back=document.querySelector('[data-nav="back"]'),forward=document.querySelector('[data-nav="forward"]'),reload=document.querySelector('[data-nav="reload"]');
  if(back){back.disabled=!state.canGoBack;back.title=state.canGoBack?'Back (Alt+Left)':'Back';}
  if(forward){forward.disabled=!state.canGoForward;forward.title=state.canGoForward?'Forward (Alt+Right)':'Forward';}
  $('externalSite').disabled = !state.canReload;
  if(reload){reload.disabled=!state.canReload;reload.title=state.canReload?'Reload (Ctrl+R)':'Reload';}
}

let settingsDirty=false;
function renderSection(id){
  if(!id)return;
  if(id==='sec-profiles')renderProfiles();
  else if(id==='sec-proxies')renderProxies();
  else if(id==='sec-extensions')renderExtensions();
  else if(id==='sec-accounts'&&typeof renderAccounts==='function')renderAccounts();
  else if(id==='sec-settings'&&!settingsDirty)renderSettings();
}

function updateSelectAll(visible=listProfiles()){
  const chosen=visible.filter(p=>selected.has(p.id)).length,all=$('all');
  if(!all)return;
  all.checked=visible.length>0&&chosen===visible.length;
  all.indeterminate=chosen>0&&chosen<visible.length;
}

function orderedTabs(){
  const byId=new Map(state.tabs.map(tab=>[tab.id,tab]));
  stableTabIds=stableTabIds.filter(id=>byId.has(id));
  const known=new Set(stableTabIds);
  const fresh=state.tabs.filter(tab=>!known.has(tab.id));
  if(pendingLaunchBatches.length&&fresh.length>1){
    const rank=new Map();let next=0;
    for(const batch of pendingLaunchBatches)for(const id of batch.ids)if(!rank.has(id))rank.set(id,next++);
    fresh.sort((a,b)=>(rank.get(a.profileId)??Number.MAX_SAFE_INTEGER)-(rank.get(b.profileId)??Number.MAX_SAFE_INTEGER));
  }
  for(const tab of fresh){stableTabIds.push(tab.id);known.add(tab.id);}
  return stableTabIds.map(id=>byId.get(id));
}

// The native host may reuse a closed tab's slot. Keep existing tabs where the
// user left them, append new ones, then persist that order through its API.
function syncTabOrder(){
  if(draggedTabId||tabOrderSyncInFlight||!stableTabIds.length)return;
  const actual=state.tabs.map(tab=>tab.id),desired=[...stableTabIds];
  if(actual.length===desired.length&&actual.every((id,index)=>id===desired[index]))return;
  const sentKey=JSON.stringify(desired);
  if(tabOrderSyncFailedKey===sentKey)return;
  tabOrderSyncInFlight=true;
  call('reorderTabs',{ids:desired}).then(()=>{tabOrderSyncFailedKey='';},error=>{
    tabOrderSyncFailedKey=sentKey;toast('Could not save tab order. '+error.message);
  }).finally(()=>{
    tabOrderSyncInFlight=false;
    if(JSON.stringify(stableTabIds)!==sentKey)syncTabOrder();
  });
}

function tabSignature(tabs,profileNames){
  return [state.workspace?1:0,state.manager?1:0,state.active||'',...tabs.map(t=>[t.id,t.profileId,t.profileName||profileNames.get(t.profileId)||'',t.title||'',t.loading?1:0,t.error||''].join('\u001f'))].join('\u001e');
}

function renderTabs(profile){
  const tabs=orderedTabs(),profileNames=new Map(state.profiles.map(item=>[item.id,item.name])),signature=tabSignature(tabs,profileNames);
  if(draggedTabId){tabRenderPending=true;return;}
  if(signature===lastTabSignature){syncTabOrder();return;}
  lastTabSignature=signature;
  const tabStrip=$('tabs'),previousTop=tabStrip.scrollTop,previousLeft=tabStrip.scrollLeft;
  tabStrip.innerHTML=(state.workspace?`<div role="tab" tabindex="0" aria-selected="${Boolean(state.manager)}" class="tab ${state.manager?'active':''}" data-home><span>Workspace</span><button data-close-workspace title="Close workspace">&times;</button></div>`:'')+tabs.map(t=>{
    const name=t.profileName||profileNames.get(t.profileId)||'',title=t.title||'New tab';
    const label=name?(title==='New tab'||title==='about:blank'?name:`${name} · ${title}`):title;
    return `<div role="tab" tabindex="0" aria-selected="${t.id===state.active&&!state.manager}" class="tab ${t.id===state.active&&!state.manager?'active':''}" data-tab="${t.id}" draggable="true" title="${esc(t.error||label)}">
      <span>${t.loading?'&#8635; ':''}${esc(label)}</span>
      <button data-paste="${t.id}" title="Paste &amp; Go">&#10549;</button>
      <button data-close="${t.id}" title="Close tab">&times;</button>
    </div>`;
  }).join('');
  if(state.active&&state.active!==lastRevealedTab){
    const activeTabEl=tabStrip.querySelector(`[data-tab="${CSS.escape(state.active)}"]`);
    if(activeTabEl)activeTabEl.scrollIntoView({block:'nearest',inline:'nearest'});
  }else{tabStrip.scrollTop=previousTop;tabStrip.scrollLeft=previousLeft;}
  lastRevealedTab=state.active||'';
  syncTabOrder();
}

function renderExtensionButtons(profile){
  const group=state.groups.find(g=>g.folders.includes(profile?.folder));
  $('extensionButtons').innerHTML=[...new Set([...(profile?.extensions||[]),...(group?.extensions||[])])].map(id=>{
    const e=state.extensions.find(e=>e.id===id);
    return e?`<button data-extension="${id}" title="${esc(e.name)}" class="btn-extension-icon">${esc(e.name.charAt(0).toUpperCase())}</button>`:'';
  }).join('');
}

function renderProfiles(){
  const profileIds=new Set(state.profiles.map(p=>p.id));
  selected=new Set([...selected].filter(id=>profileIds.has(id)));
  $('folders').innerHTML=opts([{id:'all',name:'All folders'},...state.folders],folder);
  const allTags=[...new Set(state.profiles.flatMap(p=>p.tags||[]))].filter(Boolean);
  $('tagFilter').innerHTML=opts([{id:'all',name:'All tags'},...allTags.map(t=>({id:t,name:'#'+t}))],selectedTagFilter);
  $('proxyStateFilter').value=proxyStateFilter;

  $('profileTotal').textContent=state.profiles.length;
  const visible=listProfiles(),tabCounts=new Map(),folderNames=new Map(state.folders.map(f=>[f.id,f.name])),proxyNames=new Map(state.proxies.map(x=>[x.id,x.name]));
  state.tabs.forEach(t=>tabCounts.set(t.profileId,(tabCounts.get(t.profileId)||0)+1));
  const acctMap=new Map();
  (state.accounts||[]).forEach(a=>{if(a.profileId){if(!acctMap.has(a.profileId))acctMap.set(a.profileId,[]);acctMap.get(a.profileId).push(a.service);}});

  const profileRows=visible.map(p=>{
    const tags=(p.tags||[]).map(t=>`<span class="tag-pill">#${esc(t)}</span>`).join('')||'<span class="empty-value" aria-label="No tags">—</span>';
    const count=tabCounts.get(p.id)||0;
    const status=p.status||'Ready';
    const statusClass=status==='Running'?'status-running':status==='Error'?'status-error':status==='Needs proxy'?'status-warning':'status-ready';
    const acctServices=acctMap.get(p.id)||[];
    const acctBadges=acctServices.map(s=>`<span class="acct-service-badge">${esc(s)}</span>`).join('');
    return {id:p.id,html:`<tr data-row-id="${p.id}" class="${count?'profile-launched':''} ${dragLaunchSet.has(p.id)?'drag-target':''}">
      <td><input type="checkbox" data-select="${p.id}" ${selected.has(p.id)?'checked':''} aria-label="Select ${esc(p.name)}"></td>
      <td>
        <div class="profile-identity">
          <div class="profile-name"><strong>${esc(p.name)}</strong><small class="profile-status ${statusClass}">${esc(status)}${p.notes?' · '+esc(p.notes.slice(0,48)):''}</small></div>
        </div>
      </td>
      <td>${tags}</td>
      <td>${esc(folderNames.get(p.folder)||'Profiles')}</td>
      <td><span class="badge ${p.proxyId?'badge-proxy':'badge-direct'}">${esc(proxyNames.get(p.proxyId)||'Direct')}</span></td>
      <td><span class="tab-count">${count}</span>${acctBadges}</td>
      <td>
        <button data-open="${p.id}" title="Open copied link" class="btn-action">Open</button>
        <button data-edit="${p.id}" title="Profile settings" class="btn-action">Edit</button>
      </td>
    </tr>`};
  });
  updateProfileRows(profileRows);

  const empty=$('empty');
  empty.classList.toggle('hidden',visible.length>0);
  empty.textContent=state.profiles.length?'No profiles match the current filters. Adjust the search or filters to see more.':'Create profiles to start. Each profile runs with isolated storage and separate browsing data.';
  updateSelectAll(visible);

  $('queueStatus').innerHTML='';
  updateLaunchButtons(visible);
}

function render(){
  $('updateNotice').classList.toggle('hidden',!state.updateVersion);
  $('updateVersion').textContent=state.updateVersion||'';
  const manager=Boolean(state.manager);
  document.body.classList.toggle('vertical',Boolean(state.vertical));
  document.body.classList.toggle('manager-mode',manager);
  $('manager').classList.toggle('hidden',!manager);

  const active=state.tabs.find(t=>t.id===state.active),profile=state.profiles.find(p=>p.id===active?.profileId);
  $('identity').textContent=manager?'':profile?.name||'';
  if(document.activeElement!==$('address'))$('address').value=manager?'':active?.url==='about:blank'?'':active?.url||'';
  $('address').disabled=!active;
  $('live').textContent=state.live+' profiles active · '+state.tabs.length+' tabs';
  $('engine').textContent='Pull Browser 7.0.0 · WebView2 · Chromium '+state.engine;
  $('pageMessage').textContent='';
  updateNavState();

  const headerBadge=$('headerProfileBadge');
  if(headerBadge){
    if(!manager&&profile){
      headerBadge.innerHTML=`<span class="badge-dot" style="background:${profile.color||'#7ee787'}"></span><span>${esc(profile.name)}</span>`;
      headerBadge.classList.remove('hidden');
      headerBadge.title=`Rename profile: ${profile.name}`;
      headerBadge.onclick=()=>run('renameProfile',{id:profile.id});
    }else{
      headerBadge.classList.add('hidden');
      headerBadge.innerHTML='';
    }
  }

  const canClearHistory=!manager&&Boolean(profile);
  const fillButton=$('fillLogin');
  fillButton.disabled=!canClearHistory || !state.accountAutofill || !active?.url?.startsWith('https:') || active.loading;
  fillButton.title=state.accountAutofill?'Fill saved login for this page':'Enable account autofill in Settings';
  $('historyBtn').disabled=!canClearHistory;
  $('historyBtn').title=canClearHistory?'Clear browsing data for this profile':'Clear browsing data (open a profile first)';

  renderExtensionButtons(profile);
  renderTabs(profile);
  if(manager){
    renderSection(document.querySelector('.page-section.active')?.id);
  }
}

/* ─── SECTION NAVIGATION ─── */
function showSection(id){
  document.querySelectorAll('.page-section').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active'));
  document.getElementById(id)?.classList.add('active');
  const activeNav=document.querySelector(`.nav-btn[data-section="${id}"]`);
  document.querySelectorAll('.nav-btn').forEach(b=>b.removeAttribute('aria-current'));
  activeNav?.classList.add('active');
  activeNav?.setAttribute('aria-current','page');
  renderSection(id);
}

document.querySelectorAll('.nav-btn').forEach(btn=>{
  btn.onclick=()=>{
    run('manager');
    showSection(btn.dataset.section);
  };
});

$('home').onclick=()=>{run('manager');showSection('sec-profiles');};

/* ─── MODAL ─── */
function modal(title,body,submit){
  run('manager');
  if($('modal').open)$('modal').close();
  $('modalTitle').textContent=title;
  $('modalBody').innerHTML='<p id="formError" class="error" role="alert"></p>'+body;
  $('modal').showModal();
  const form=$('modalBody').querySelector('form');
  if(form&&submit)form.onsubmit=async event=>{
    event.preventDefault();
    const button=form.querySelector('[type=submit]');
    if(button)button.disabled=true;
    try{await submit(new FormData(form));$('modal').close();}
    catch(e){$('formError').textContent=e.message;$('formError').tabIndex=-1;$('formError').focus();}
    finally{if(button)button.disabled=false;}
  };
}
const saveButton=label=>`<div class="formActions"><button type="submit" class="btn-primary">${label||'Save'}</button></div>`;
$('modalClose').onclick=()=>$('modal').close();
$('modal').addEventListener('close',()=>{
  if($('modal').open)return;
  for(const field of $('modalBody').querySelectorAll('input[type="password"], [data-credential-input]'))field.value='';
});

/* ─── TAB DRAG, REORDER & DETACH SUPPORT ─── */

$('tabs').addEventListener('dragstart', e => {
  const tab = e.target.closest('[data-tab]');
  if (!tab) return;
  draggedTabId = tab.dataset.tab;
  e.dataTransfer.setData('text/plain', draggedTabId);
  e.dataTransfer.effectAllowed = 'move';
  tab.classList.add('is-dragging');
});

$('tabs').addEventListener('dragover', e => {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  const targetTab = e.target.closest('[data-tab]');
  document.querySelectorAll('#tabs .tab').forEach(t => t.classList.remove('drag-over-before', 'drag-over-after'));
  if (targetTab && targetTab.dataset.tab !== draggedTabId) {
    const rect = targetTab.getBoundingClientRect();
    if (state.vertical) {
      if (e.clientY < rect.top + rect.height / 2) targetTab.classList.add('drag-over-before');
      else targetTab.classList.add('drag-over-after');
    } else {
      if (e.clientX < rect.left + rect.width / 2) targetTab.classList.add('drag-over-before');
      else targetTab.classList.add('drag-over-after');
    }
  }
});

document.addEventListener('dragover', e => {
  e.preventDefault();
});

document.addEventListener('drop', e => {
  e.preventDefault();
  if (!draggedTabId) return;
  
  const tabsBounds = $('tabs').getBoundingClientRect();
  const insideTabs = (
    e.clientX >= tabsBounds.left && e.clientX <= tabsBounds.right &&
    e.clientY >= tabsBounds.top && e.clientY <= tabsBounds.bottom
  );
  
  if (!insideTabs) {
    run('detach', { id: draggedTabId });
  } else {
    const targetTab = e.target.closest('[data-tab]');
    const draggedEl = $('tabs').querySelector(`[data-tab="${draggedTabId}"]`);
    if (targetTab && draggedEl && targetTab !== draggedEl) {
      const rect = targetTab.getBoundingClientRect();
      const insertBefore = state.vertical ? (e.clientY < rect.top + rect.height / 2) : (e.clientX < rect.left + rect.width / 2);
      if (insertBefore) targetTab.before(draggedEl);
      else targetTab.after(draggedEl);

      const existing=new Set(state.tabs.map(tab=>tab.id));
      const newIds=Array.from($('tabs').querySelectorAll('[data-tab]')).map(el=>el.dataset.tab).filter(id=>existing.has(id));
      const placed=new Set(newIds);
      stableTabIds=[...newIds,...stableTabIds.filter(id=>existing.has(id)&&!placed.has(id))];
      tabOrderSyncFailedKey='';
    }
  }
  document.querySelectorAll('#tabs .tab').forEach(t => t.classList.remove('drag-over-before', 'drag-over-after', 'is-dragging'));
  draggedTabId = null;
  if(tabRenderPending){tabRenderPending=false;lastTabSignature='';renderTabs();}else syncTabOrder();
});

$('tabs').addEventListener('dragend', e => {
  if(draggedTabId && (e.clientX<0 || e.clientY<0 || e.clientX>=innerWidth || e.clientY>=innerHeight))run('detach',{id:draggedTabId});
  document.querySelectorAll('#tabs .tab').forEach(t => t.classList.remove('drag-over-before', 'drag-over-after', 'is-dragging'));
  draggedTabId = null;
  if(tabRenderPending){tabRenderPending=false;lastTabSignature='';renderTabs();}else syncTabOrder();
});

/* --- TAB STRIP MOUSE WHEEL SCROLL (150+ tabs scrollable without hiding) --- */
$('tabs').addEventListener('wheel', e => {
  e.preventDefault();
  const tabsEl = $('tabs');
  if (state.vertical) {
    tabsEl.scrollTop += (e.deltaY || e.deltaX);
  } else {
    tabsEl.scrollLeft += (e.deltaY || e.deltaX);
  }
}, { passive: false });

/* --- TAB KEYBOARD NAVIGATION (Ctrl + Up/Down for vertical, Ctrl + Left/Right for horizontal) --- */
document.addEventListener('keydown', e => {
  if (!e.ctrlKey || e.altKey || e.metaKey || e.shiftKey || e.target.closest('input, textarea, select, [contenteditable="true"]')) return;
  const isVert = Boolean(state.vertical);
  const prevKey = isVert ? 'ArrowUp' : 'ArrowLeft';
  const nextKey = isVert ? 'ArrowDown' : 'ArrowRight';
  if (e.key !== prevKey && e.key !== nextKey) return;
  e.preventDefault();
  
  const tabEls = Array.from($('tabs').querySelectorAll('[data-tab]'));
  if (!tabEls.length) return;
  const activeIdx = tabEls.findIndex(t => t.dataset.tab === state.active);
  let newIdx = activeIdx;
  if (e.key === prevKey) {
    newIdx = activeIdx > 0 ? activeIdx - 1 : tabEls.length - 1;
  } else if (e.key === nextKey) {
    newIdx = activeIdx < tabEls.length - 1 ? activeIdx + 1 : 0;
  }
  if (newIdx !== activeIdx && tabEls[newIdx]) {
    const nextTabId = tabEls[newIdx].dataset.tab;
    run('activate', { id: nextTabId });
    tabEls[newIdx].scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'auto' });
  }
});

/* Native drag and drop handles tab ordering and cancellation. */

$('drag').onmousedown=()=>run('drag');
$('drag').ondblclick=()=>run('window',{command:'maximize'});
document.querySelectorAll('[data-window]').forEach(b=>b.onclick=()=>run('window',{command:b.dataset.window}));
document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>run('nav',{command:b.dataset.nav}));
$('externalSite').onclick=()=>run('externalSite');
$('paste').onclick=()=>run('pasteGo');
$('help').onclick=()=>run('help');
$('addressForm').onsubmit=e=>{e.preventDefault();run('navigate',{url:$('address').value});};
$('folders').onchange=()=>{selected.clear();dragLaunchSet.clear();folder=$('folders').value;render();};
$('tagFilter').onchange=()=>{selectedTagFilter=$('tagFilter').value;render();};
$('proxyStateFilter').onchange=()=>{proxyStateFilter=$('proxyStateFilter').value;render();};
$('search').oninput=render;

$('tabs').onclick=e=>{
  const b=e.target.closest('button');
  if(b?.dataset.close)run('close',{id:b.dataset.close});
  else if(b?.dataset.paste)run('pasteGo',{id:b.dataset.paste});
  else if(b?.hasAttribute('data-close-workspace'))run('closeWorkspace');
  else if(e.target.closest('[data-home]'))run('manager');
  else{const tab=e.target.closest('[data-tab]');if(tab)run('activate',{id:tab.dataset.tab});}
};

/* ─── CLEAR HISTORY & COOKIES (SPECIFIC TO CURRENT OPEN PROFILE) ─── */
$('fillLogin').onclick=async()=>{
  const message=await run('fillLogin');
  if(message)toast(message);
};
$('historyBtn').onclick=()=>{
  run('showHistoryDialog');
};

/* ─── PROFILE FOLDER MANAGEMENT MODAL ─── */
$('manageFoldersBtn').onclick=()=>{
  const content=`
    <div style="margin-bottom:16px">
      <label class="field"><span>Create New Folder</span>
        <div style="display:flex;gap:8px">
          <input id="newFolderName" placeholder="Folder name" style="flex:1;min-width:0;width:auto"><input id="newFolderColor" type="color" value="#b0a0e4">
          <button type="button" id="addNewFolderBtn" class="btn-primary">Add Folder</button>
        </div>
      </label>
    </div>
    <div class="proxy-section-header"><h3>EXISTING PROFILE FOLDERS</h3></div>
    <div class="list" style="max-height:300px;overflow-y:auto">
      ${state.folders.map(f=>`
        <div class="entry" style="display:flex;align-items:center;justify-content:space-between;gap:8px">
          <i class="folder-color" style="background:${esc(f.Color||f.color||'#b0a0e4')}"></i><input type="text" value="${esc(f.Name||f.name)}" data-folder-edit-id="${f.Id||f.id}" style="flex:1;background:#1e1e1e"><input type="color" value="${esc(f.Color||f.color||'#b0a0e4')}" data-folder-color-id="${f.Id||f.id}">
          <button type="button" class="btn-secondary" data-save-folder="${f.Id||f.id}">Rename</button>
          ${(f.Id||f.id)!=='default'?`<button type="button" class="btn-danger" data-delete-folder="${f.Id||f.id}">Delete</button>`:'<span style="font-size:11px;color:#888;padding:0 8px">Default</span>'}
        </div>
      `).join('')}
    </div>
  `;
  modal('Manage Profile Folders',content);
  
  $('addNewFolderBtn').onclick=async()=>{
    const name=$('newFolderName').value.trim();
    if(!name){toast('Please enter a folder name.');return;}
    try{
      await call('folder',{name,color:$('newFolderColor').value});
      state=await call('state');
      render();
      $('manageFoldersBtn').click();
    }catch(e){toast(e.message);}
  };
  
  $('modalBody').querySelectorAll('[data-save-folder]').forEach(b=>{
    b.onclick=async()=>{
      const id=b.dataset.saveFolder;
      const input=$('modalBody').querySelector(`[data-folder-edit-id="${id}"]`);
      if(!input||!input.value.trim()){toast('Name cannot be empty.');return;}
      try{
        await call('editFolder',{id,name:input.value.trim(),color:$('modalBody').querySelector(`[data-folder-color-id="${id}"]`).value});
        state=await call('state');
        render();
        toast('Folder renamed.');
      }catch(e){toast(e.message);}
    };
  });
  
  $('modalBody').querySelectorAll('[data-delete-folder]').forEach(b=>{
    b.onclick=async()=>{
      const id=b.dataset.deleteFolder;
      if(!confirm('Delete this folder? Profiles will be moved to default folder.'))return;
      try{
        await call('deleteFolder',{id});
        state=await call('state');
        render();
        $('manageFoldersBtn').click();
      }catch(e){toast(e.message);}
    };
  });
};

/* ─── PROFILE SELECTION & LAUNCH ─── */
$('rows').onchange=e=>{
  if(e.target.dataset.select){
    if(e.target.checked)selected.add(e.target.dataset.select);
    else selected.delete(e.target.dataset.select);
    updateLaunchButtons();
    updateSelectAll();
  }
};
$('all').onchange=()=>{
  for(const p of listProfiles())if($('all').checked)selected.add(p.id);else selected.delete(p.id);
  render();
};
$('rows').onclick=e=>{
  const b=e.target.closest('button');
  if(b?.dataset.open)run('open',{id:b.dataset.open,reuse:true});
  if(b?.dataset.edit)editProfile(b.dataset.edit);
};


/* --- IN-ORDER BATCH LAUNCHER (Awake tabs launched sequentially in list order) --- */
function getOrderedProfileIds(profileIds) {
  if (!profileIds || !profileIds.length) return [];
  const rowElements = Array.from($('rows').querySelectorAll('tr[data-row-id]'));
  const rowOrder = rowElements.map(r => r.dataset.rowId);
  const idSet = new Set(profileIds);
  const orderedIds = [];
  for (const id of rowOrder) {
    if (idSet.has(id)) orderedIds.push(id);
  }
  for (const id of profileIds) {
    if (!orderedIds.includes(id)) orderedIds.push(id);
  }
  return orderedIds;
}

$('launch').onclick = () => {
  const orderedIds = getOrderedProfileIds(selectedVisibleIds());
  if (!orderedIds.length) { toast('Select visible profiles first.'); return; }
  toast(`Opening ${orderedIds.length} profiles...`);
  run('launch', { ids: orderedIds, blank: false });
};

$('clearProfileSelection').onclick=()=>{selected.clear();render();};

$('bulkTags').onclick=()=>{
  const ids=selectedVisibleIds();
  if(!ids.length){toast('Select visible profiles first.');return;}
  modal('Bulk edit tags',`<form>
    <label class="field"><span>Action</span><select name="mode"><option value="add">Add these tags</option><option value="remove">Remove these tags</option><option value="replace">Replace all tags</option></select></label>
    <label class="field"><span>Tags (comma-separated)</span><input name="tags" placeholder="e.g. ticketing, priority" required></label>
    <p class="hint">Applies to ${ids.length} selected profile${ids.length===1?'':'s'} in this view.</p>
    ${saveButton('Apply tags')}
  </form>`,data=>call('bulkTags',{...Object.fromEntries(data),ids}));
};
$('bulkProxy').onclick=()=>{
  const ids=selectedVisibleIds();
  if(!ids.length){toast('Select visible profiles first.');return;}
  modal('Assign proxies',`<form>
    <p class="hint">Choose how to update ${ids.length} selected profile${ids.length===1?'':'s'} in this view. Close launched profiles first.</p>
    <label class="field"><span>Assignment</span><select id="proxyAssignmentMode" name="mode"><option value="unused">Use a different unused proxy for each profile</option><option value="shared">Use the same proxy for every profile</option><option value="direct">Remove proxies and use a direct connection</option></select></label>
    <label class="field" id="proxyAssignmentFolder"><span>Choose from</span><select name="folder">${opts(state.proxyFolders,'','All proxy folders')}</select></label>
    <label class="field" id="proxyAssignmentShared" hidden><span>Proxy</span><select name="proxyId">${opts(state.proxies,'','Choose a proxy')}</select></label>
    ${saveButton('Apply assignment')}
  </form>`,data=>{
    const mode=data.get('mode');
    if(mode==='unused')return call('assignUnused',{ids,folder:data.get('folder')});
    if(mode==='direct')return call('bulkProxy',{ids,proxyId:''});
    if(!data.get('proxyId'))throw Error('Choose a proxy to assign.');
    return call('bulkProxy',{ids,proxyId:data.get('proxyId')});
  });
  const mode=$('proxyAssignmentMode');
  mode.onchange=()=>{$('proxyAssignmentFolder').hidden=mode.value!=='unused';$('proxyAssignmentShared').hidden=mode.value!=='shared';};
};
$('delete').onclick=()=>{
  if(!selected.size){toast('Select profiles first.');return;}
  const ids=selectedVisibleIds(); if(!ids.length)return toast('Select visible profiles first.');
  const names=ids.map(id=>state.profiles.find(p=>p.id===id)?.name||'Unknown');
  modal('Delete profiles',`<form><p>This permanently deletes <strong>${ids.length} profile${ids.length===1?'':'s'}</strong> and its saved browsing data.</p><p class="hint">${names.slice(0,8).map(esc).join(', ')}${names.length>8?' and '+(names.length-8)+' more':''}</p><label class="field"><span>Type DELETE to continue</span><input name="confirmation" autocomplete="off" required></label><div class="formActions"><button type="submit" class="btn-danger">Delete profiles</button></div></form>`,data=>{if(data.get('confirmation')!=='DELETE')throw Error('Type DELETE to confirm.');return call('deleteProfiles',{ids});});
};

$('create').onclick=()=>modal('Create Profiles',`<form>
  <div class="grid">
    <label class="field"><span>Name / prefix</span><input name="name" required value="Profile"></label>
    <label class="field"><span>How many?</span><input type="number" name="count" min="1" max="500" value="1" required></label>
  </div>
  <label class="field"><span>Folder</span><select name="folder">${opts(state.folders,folder)}</select></label>
  <label class="field"><span>Tags (comma-separated)</span><input name="tags" placeholder="e.g. seatgeek, axs, drop1"></label>
  <label class="field"><span>Color Code</span>
    <div class="color-palette">
      ${['#b0a0e4','#60a5fa','#34d399','#fbbf24','#f87171','#ec4899','#14b8a6','#a855f7'].map((c,i)=>`
        <label class="color-choice" style="background:${c}"><input type="radio" name="color" value="${c}" ${i===0?'checked':''}></label>
      `).join('')}
    </div>
  </label>
  ${saveButton('Create')}
</form>`,data=>call('create',Object.fromEntries(data)));

$('import').onclick=()=>modal('Import Profile Names',`<form>
  <label class="field"><span>One profile name per line</span><textarea name="text" rows="7" required></textarea></label>
  <label class="field"><span>Folder</span><select name="folder">${opts(state.folders,folder)}</select></label>
  <label class="field"><span>Tags (comma-separated)</span><input name="tags" placeholder="e.g. seatgeek, drop1"></label>
  ${saveButton('Import')}
</form>`,data=>call('importProfiles',Object.fromEntries(data)));

function editProfile(id){
  const p=state.profiles.find(p=>p.id===id);
  modal('Profile Settings',`<form>
    <label class="field"><span>Name</span><input name="name" value="${esc(p.name)}" required></label>
    <label class="field"><span>Folder</span><select name="folder">${opts(state.folders,p.folder)}</select></label>
    <label class="field"><span>Proxy</span><select name="proxyId">${opts(state.proxies.map(px=>({...px,name:px.name+(px.assigned.length?' · used by '+px.assigned.join(', '):'')})),p.proxyId,'Direct connection')}</select></label>
    <label class="field"><span>Tags (comma-separated)</span><input name="tags" value="${esc((p.tags||[]).join(', '))}" placeholder="e.g. seatgeek, drop1"></label>
    <label class="field"><span>Private notes</span><textarea name="notes" rows="3" placeholder="Optional status or reminder">${esc(p.notes||'')}</textarea></label>
    <label class="field"><span>Color Code</span>
      <div class="color-palette">
        ${['#b0a0e4','#60a5fa','#34d399','#fbbf24','#f87171','#ec4899','#14b8a6','#a855f7'].map(c=>`
          <label class="color-choice" style="background:${c}"><input type="radio" name="color" value="${c}" ${(p.color||'#b0a0e4')===c?'checked':''}></label>
        `).join('')}
      </div>
    </label>
    <label style="display:flex;align-items:center;gap:8px;margin:8px 0"><input type="checkbox" name="allowShared"> Allow a shared proxy</label>
    <p class="hint">Profile changes take effect immediately on next open without requiring application restarts.</p>
    ${saveButton()}
  </form>`,data=>call('edit',{...Object.fromEntries(data),id,allowShared:data.has('allowShared')}));
}

/* ─── DRAG-LAUNCH BUTTON TOGGLE & INTERACTION ─── */
$('dragLaunchBtn').onclick=()=>{
  dragLaunchActive=!dragLaunchActive;
  $('dragLaunchBtn').textContent=dragLaunchActive?'Drag launch: On':'Drag launch: Off';
  $('dragLaunchBtn').setAttribute('aria-pressed',String(dragLaunchActive));
  $('dragLaunchBtn').classList.toggle('active',dragLaunchActive);
  toast(dragLaunchActive?'Drag-Launch enabled: Drag mouse across profiles to launch with copied link':'Drag-Launch disabled');
};

/* Shared profile selection and the existing drag-launch behavior. */
const profileDragLaunch={
  enabled:event=>dragLaunchActive||event.altKey,
  start(row){
    dragLaunchSet.clear();
    document.querySelectorAll('#rows tr.drag-target').forEach(item=>item.classList.remove('drag-target'));
    this.add(row);
  },
  add(row){
    const id=row.dataset.rowId;
    if(!id||dragLaunchSet.has(id))return;
    dragLaunchSet.add(id);row.classList.add('drag-target');
    $('dragLaunchCount').textContent=dragLaunchSet.size;
    $('dragLaunchBanner').style.display='block';
  },
  clear(){
    dragLaunchSet.clear();$('dragLaunchBanner').style.display='none';
    document.querySelectorAll('#rows tr.drag-target').forEach(row=>row.classList.remove('drag-target'));
  },
  finish(){
    const ids=getOrderedProfileIds([...dragLaunchSet]);this.clear();
    if(ids.length){toast(`Opening ${ids.length} profiles...`);run('launch',{ids,blank:false});}
  },
  cancel(){this.clear();}
};
installMarqueeSelection({
  root:$('rows'),rowSelector:'tr[data-row-id]',checkboxSelector:'input[data-select]',
  getSelection:()=>selected,onChange:()=>{updateLaunchButtons();updateSelectAll();},launch:profileDragLaunch
});

/* ─── PROXIES PAGE ─── */
function renderProxies(){
  const c=$('proxyContent');if(!c)return;
  const validProxyIds=new Set(state.proxies.map(p=>p.id||p.Id));
  for(const id of selectedProxies)if(!validProxyIds.has(id))selectedProxies.delete(id);
  const filteredFolders=selectedProxyFolder==='all'?state.proxyFolders:state.proxyFolders.filter(f=>f.Id===selectedProxyFolder||f.id===selectedProxyFolder);

  c.innerHTML=`
    <div class="proxy-controls-bar">
      <div class="folder-pills">
        <button class="pill ${selectedProxyFolder==='all'?'active':''}" data-proxy-folder="all">All Folders (${state.proxies.length})</button>
        ${state.proxyFolders.map(f=>{
          const count=state.proxies.filter(p=>p.folder===(f.Id||f.id)||p.Folder===(f.Id||f.id)).length;
          return `<button class="pill ${selectedProxyFolder===(f.Id||f.id)?'active':''}" data-proxy-folder="${esc(f.Id||f.id)}"><i class="folder-color" style="background:${esc(f.Color||f.color||'#b0a0e4')}"></i>${esc(f.Name||f.name)} (${count})</button>`;
        }).join('')}
      </div>
      <div class="proxy-filter-subbar">
        <div class="filter-group">
          <button class="filter-btn ${proxyAssignFilter==='all'?'active':''}" data-assign-filter="all">All</button>
          <button class="filter-btn ${proxyAssignFilter==='assigned'?'active':''}" data-assign-filter="assigned">Assigned</button>
          <button class="filter-btn ${proxyAssignFilter==='unassigned'?'active':''}" data-assign-filter="unassigned">Unassigned</button>
        </div>
        <input id="proxySearch" aria-label="Search proxies" placeholder="Search proxies…" value="${esc(proxySearchQuery)}">
      </div>
      <div class="workspace-toolbar proxy-selection-toolbar">
        <div class="selection-meta"><span id="proxySelectionSummary" class="selection-summary" aria-live="polite"></span><span class="selection-hint" title="Drag across rows or Shift-click checkboxes to select a range">Drag to select</span></div>
      </div>
    </div>

    ${showProxyImport?`
      <div class="import-box">
        <h3>IMPORT PROXIES</h3>
        <form id="proxyImportForm">
          <label class="field"><span>Target Folder</span>
            <select name="folder">${opts(state.proxyFolders,selectedProxyFolder==='all'?'default':selectedProxyFolder)}</select>
          </label>
          <label class="field"><span>One per line — format: <code>ip:port:user:pass</code> or <code>label|ip:port:user:pass</code></span>
            <textarea name="text" rows="6" required placeholder="Proxy 1|http://username:password@proxy.example:8080&#10;proxy.example:8080:username:password"></textarea>
          </label>
          <div class="formActions">
            <button type="button" id="cancelImportBtn" class="btn-secondary">Cancel</button>
            <button type="submit" class="btn-primary">Import Proxies</button>
          </div>
        </form>
      </div>
    `:''}

    ${filteredFolders.map(f=>{
      const fid=f.Id||f.id;
      let proxies=state.proxies.filter(p=>(p.folder===fid||p.Folder===fid));
      if(proxyAssignFilter==='assigned')proxies=proxies.filter(p=>p.assigned&&p.assigned.length>0);
      else if(proxyAssignFilter==='unassigned')proxies=proxies.filter(p=>!p.assigned||p.assigned.length===0);
      if(proxySearchQuery){
        const q=proxySearchQuery.toLowerCase();
        proxies=proxies.filter(p=>(p.name||p.Name||'').toLowerCase().includes(q)||(p.label||p.Label||'').toLowerCase().includes(q));
      }

      return `
        <div class="card proxy-folder-card" style="margin-top:14px;border-left:3px solid ${esc(f.Color||f.color||'#b0a0e4')}">
          <div class="card-header">
            <div style="display:flex;align-items:center;gap:10px">
              <i class="folder-color" style="background:${esc(f.Color||f.color||'#b0a0e4')}"></i><strong style="font-size:14px;color:#e8e8e8">${esc(f.Name||f.name)}</strong>
              <span class="badge ${proxies.length>0?'badge-proxy':'badge-direct'}">${proxies.length} proxies</span>
              <span class="badge badge-direct" style="font-size:10px">${proxies.filter(p=>p.assigned&&p.assigned.length>0).length} assigned</span>
            </div>
            <div class="tools">${fid!=='default'?`<details class="action-menu row-menu"><summary aria-label="Actions for ${esc(f.Name||f.name)} folder">Folder actions <svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 6 4 4 4-4"></path></svg></summary><div class="action-menu-panel"><button type="button" data-edit-proxy-folder="${fid}">Edit folder</button><button type="button" class="menu-danger" data-delete-proxy-folder="${fid}">Delete folder</button></div></details>`:''}</div>
          </div>
          ${proxies.length===0?`<p style="color:#666;font-size:12px;margin:8px 0">No proxies in this folder matching filters.</p>`:`
            <div class="folder-selection"><label><input type="checkbox" id="proxySelectAll-${fid}" ${proxies.length>0&&proxies.every(p=>selectedProxies.has(p.id||p.Id))?'checked':''} aria-label="Select visible proxies in ${esc(f.Name||f.name)}"> Select visible</label></div>
            <table class="compact-table">
              <thead><tr><th style="width:32px"></th><th>NAME</th><th>ENDPOINT / LABEL</th><th>ASSIGNED PROFILES</th><th style="text-align:right">ACTIONS</th></tr></thead>
              <tbody data-proxy-tbody="${fid}">
                ${proxies.map(p=>`
                  <tr data-row-id="${p.id||p.Id}">
                    <td><input type="checkbox" data-proxy-select="${p.id||p.Id}" ${selectedProxies.has(p.id||p.Id)?'checked':''} aria-label="Select ${esc(p.name||p.Name)}"></td>
                    <td><strong>${esc(p.name||p.Name)}</strong></td>
                    <td><code>${esc(p.label||p.Label||'Direct')}</code></td>
                    <td>${(p.assigned&&p.assigned.length)?`<span class="proxy-assign-count">${p.assigned.length}</span> `+p.assigned.slice(0,3).map(n=>`<span class="badge badge-profile">${esc(n)}</span>`).join('')+(p.assigned.length>3?` <span style="color:#666;font-size:10px">+${p.assigned.length-3} more</span>`:''):'<span class="proxy-unassigned-label">Unassigned</span>'}</td>
                    <td class="row-actions"><details class="action-menu row-menu"><summary aria-label="Actions for ${esc(p.name||p.Name)}">Actions <svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 6 4 4 4-4"></path></svg></summary><div class="action-menu-panel"><button type="button" data-edit-proxy="${p.id||p.Id}">Edit or move</button><button type="button" class="menu-danger" data-delete-proxy="${p.id||p.Id}">Delete proxy</button></div></details></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          `}
        </div>
      `;
    }).join('')}
  `;

  c.querySelectorAll('[data-proxy-folder]').forEach(btn=>{
    btn.onclick=()=>{selectedProxyFolder=btn.dataset.proxyFolder;renderProxies();};
  });
  c.querySelectorAll('[data-edit-proxy]').forEach(b=>b.onclick=()=>{const p=state.proxies.find(x=>x.id===b.dataset.editProxy);modal('Manage proxy',`<form><label class="field">Name<input name="name" value="${esc(p.name)}" required></label><label class="field">Folder<select name="folder">${opts(state.proxyFolders,p.folder)}</select></label>${saveButton()}</form>`,f=>call('proxyEditLabel',{id:p.id,...Object.fromEntries(f)}));});
  c.querySelectorAll('[data-assign-filter]').forEach(btn=>{
    btn.onclick=()=>{proxyAssignFilter=btn.dataset.assignFilter;renderProxies();};
  });
  const searchInput=c.querySelector('#proxySearch');
  if(searchInput){
    searchInput.oninput=()=>{proxySearchQuery=searchInput.value;renderProxies();const input=c.querySelector('#proxySearch');input.focus();input.setSelectionRange(input.value.length,input.value.length);};
  }
  const cancelBtn=c.querySelector('#cancelImportBtn');
  if(cancelBtn)cancelBtn.onclick=()=>{showProxyImport=false;renderProxies();};
  const importForm=c.querySelector('#proxyImportForm');
  if(importForm){
    importForm.onsubmit=async e=>{
      e.preventDefault();
      try{
        const formData = Object.fromEntries(new FormData(importForm));
        if (formData.text) {
          formData.text = formData.text.split('\n').map(line => {
            line = line.trim();
            if (!line || line.includes('|')) return line;
            const parts = line.split(':');
            if (parts.length >= 5) {
              const port = Number(parts[2]);
              if (Number.isInteger(port) && port >= 1 && port <= 65535) {
                const name = parts[0].trim();
                const rest = parts.slice(1).join(':').trim();
                return `${name}|${rest}`;
              }
            }
            return line;
          }).join('\n');
        }
        await call('importProxies', formData);
        showProxyImport=false;
        state=await call('state');
        render();
        toast('Proxies imported successfully.');
      }catch(err){toast(err.message);}
    };
  }
  c.querySelectorAll('[data-delete-proxy]').forEach(btn=>{
    btn.onclick=()=>{
      const id=btn.dataset.deleteProxy, proxy=state.proxies.find(p=>(p.id||p.Id)===id);
      modal('Delete proxy',`<form><p>Delete <strong>${esc(proxy?.name||proxy?.Name||'this proxy')}</strong>?</p><p class="hint">A proxy assigned to a profile must be unassigned before it can be deleted.</p><div class="formActions"><button type="submit" class="btn-danger">Delete proxy</button></div></form>`,async()=>{
        await call('deleteProxy',{id});selectedProxies.delete(id);state=await call('state');render();toast('Proxy deleted.');
      });
    };
  });
  c.querySelectorAll('[data-delete-proxy-folder]').forEach(btn=>{
    btn.onclick=async()=>{
      if(!confirm('Delete this proxy folder?'))return;
      try{
        await call('deleteProxyFolder',{id:btn.dataset.deleteProxyFolder});
        state=await call('state');
        render();
        toast('Proxy folder deleted.');
      }catch(err){toast(err.message);}
    };
  });
  c.querySelectorAll('[data-edit-proxy-folder]').forEach(btn=>{
    btn.onclick=()=>{const f=state.proxyFolders.find(x=>(x.id||x.Id)===btn.dataset.editProxyFolder);modal('Edit proxy folder',`<form><label class="field"><span>Name</span><input name="name" value="${esc(f.name||f.Name)}" required></label><label class="field"><span>Color</span><input name="color" type="color" value="${esc(f.color||f.Color||'#b0a0e4')}"></label>${saveButton()}</form>`,data=>call('editProxyFolder',{id:btn.dataset.editProxyFolder,...Object.fromEntries(data)}));};
  });
  // proxy checkbox selection
  c.querySelectorAll('[data-proxy-select]').forEach(cb=>{
    cb.onchange=()=>{cb.checked?selectedProxies.add(cb.dataset.proxySelect):selectedProxies.delete(cb.dataset.proxySelect);updateProxySelectionUI();};
  });
  c.querySelectorAll('[id^="proxySelectAll-"]').forEach(cb=>{
    cb.onchange=()=>{
      const fid=cb.id.replace('proxySelectAll-','');
      c.querySelectorAll(`[data-proxy-tbody="${CSS.escape(fid)}"] [data-proxy-select]`).forEach(row=>{if(cb.checked)selectedProxies.add(row.dataset.proxySelect);else selectedProxies.delete(row.dataset.proxySelect);});
      updateProxySelectionUI();
    };
  });
  document.querySelectorAll('[data-proxy-bulk-delete]').forEach(btn=>{
    btn.onclick=async()=>{
      const ids=visibleSelectedProxyIds();
      if(!ids.length)return toast('Select visible proxies first.');
      modal('Delete proxies',`<form><p>Delete <strong>${ids.length} selected ${ids.length===1?'proxy':'proxies'}</strong> in this view?</p><p class="hint">Assigned proxies must be unassigned before they can be deleted.</p><div class="formActions"><button type="submit" class="btn-danger">Delete proxies</button></div></form>`,async()=>{
        let failed=0;
        for(const id of ids){try{await call('deleteProxy',{id});selectedProxies.delete(id);}catch(e){failed++;}}
        state=await call('state');render();
        toast(failed?`${ids.length-failed} deleted. ${failed} could not be deleted; check their assignments.`:`${ids.length} ${ids.length===1?'proxy':'proxies'} deleted.`);
      });
    };
  });
  document.querySelectorAll('[data-proxy-bulk-move]').forEach(btn=>{
    btn.onclick=()=>{
      const ids=visibleSelectedProxyIds();
      if(!ids.length)return toast('Select visible proxies first.');
      modal('Move selected proxies',`<form><label class="field"><span>Folder</span><select name="folder">${opts(state.proxyFolders,'default')}</select></label><p class="hint">Moves ${ids.length} selected ${ids.length===1?'proxy':'proxies'} in this view.</p>${saveButton('Move')}</form>`,async data=>{
        const folder=data.get('folder');
        let failed=0;
        for(const id of ids){
          const p=state.proxies.find(x=>(x.id||x.Id)===id); if(!p)continue;
          try{await call('proxyEditLabel',{id,name:p.name||p.Name,folder});selectedProxies.delete(id);}catch(e){failed++;}
        }
        state=await call('state');render();
        toast(failed?`${ids.length-failed} moved. ${failed} could not be moved.`:`${ids.length} ${ids.length===1?'proxy':'proxies'} moved.`);
      });
    };
  });
  $('clearProxySelection').onclick=()=>{selectedProxies.clear();c.querySelectorAll('[data-proxy-select]').forEach(cb=>{cb.checked=false;});updateProxySelectionUI();};
  updateProxySelectionUI();
}

function visibleSelectedProxyIds(){
  return [...$('proxyContent').querySelectorAll('[data-proxy-select]')].map(cb=>cb.dataset.proxySelect).filter(id=>selectedProxies.has(id));
}
function updateProxySelectionUI(){
  const c=$('proxyContent'), visible=visibleSelectedProxyIds(), hidden=selectedProxies.size-visible.length;
  const summary=$('proxySelectionSummary');
  if(summary)summary.textContent=selectedProxies.size?`${visible.length} selected${hidden?` · ${hidden} hidden`:''}`:`${c.querySelectorAll('[data-proxy-select]').length} proxies`;
  document.querySelectorAll('[data-proxy-bulk-move],[data-proxy-bulk-delete]').forEach(button=>{button.disabled=!visible.length;});
  if($('clearProxySelection'))$('clearProxySelection').disabled=!selectedProxies.size;
  c.querySelectorAll('[id^="proxySelectAll-"]').forEach(all=>{
    const fid=all.id.replace('proxySelectAll-','');
    const boxes=[...c.querySelectorAll(`[data-proxy-tbody="${CSS.escape(fid)}"] [data-proxy-select]`)];
    const checked=boxes.filter(cb=>selectedProxies.has(cb.dataset.proxySelect)).length;
    all.checked=boxes.length>0&&checked===boxes.length;all.indeterminate=checked>0&&checked<boxes.length;
  });
}
installMarqueeSelection({root:$('proxyContent'),rowSelector:'[data-proxy-tbody] tr[data-row-id]',checkboxSelector:'input[data-proxy-select]',getSelection:()=>selectedProxies,onChange:updateProxySelectionUI});

$('toggleImportBtn').onclick=()=>{showProxyImport=!showProxyImport;renderProxies();};
$('proxyFolderBtn').onclick=()=>modal('Proxy Folder',`<form><label class="field"><span>Name</span><input name="name" required></label><label class="field"><span>Color</span><input name="color" type="color" value="#b0a0e4"></label>${saveButton()}</form>`,data=>call('proxyFolder',Object.fromEntries(data)));

/* ─── EXTENSIONS PAGE ─── */
function groupEditor(id,draft){
  const g=draft||state.groups.find(g=>g.id===id)||{name:'',folders:[],extensions:[]};
  modal('Extension Group',`<form><label class="field"><span>Name</span><input name="name" value="${esc(g.name)}" required></label><button type="button" id="loadExtension" class="btn-secondary" style="margin-bottom:12px">+ Load Unpacked Extension</button><label class="field"><span>Select Extensions</span></label><div class="list">${state.extensions.map(e=>`<label><input type="checkbox" name="extensions" value="${e.id}" ${g.extensions.includes(e.id)?'checked':''}> ${esc(e.name)}</label>`).join('')}</div><label class="field"><span>Assign to Profile Folders</span></label><div class="list">${state.folders.map(f=>`<label><input type="checkbox" name="folders" value="${f.id}" ${g.folders.includes(f.id)?'checked':''}> ${esc(f.name)}</label>`).join('')}</div><p class="hint">Extensions configured here will automatically attach to profiles in the selected folders.</p>${saveButton('Save Group')}</form>`,data=>call('groupSave',{id,name:data.get('name'),folders:data.getAll('folders'),extensions:data.getAll('extensions')}));
  $('loadExtension').onclick=async()=>{
    const data=new FormData($('modalBody').querySelector('form'));
    try{const added=await call('extensionsImport');state=await call('state');groupEditor(id,{name:data.get('name'),folders:data.getAll('folders'),extensions:[...data.getAll('extensions'),...(added?[added]:[])]});}
    catch(e){$('formError').textContent=e.message;$('formError').tabIndex=-1;$('formError').focus();}
  };
}

function renderExtensions(){
  const c=$('extensionContent');if(!c)return;
  c.innerHTML=state.groups.length===0?`
    <div class="empty-panel"><strong>No extension groups yet</strong><p>Create a group to connect extensions to profile folders.</p></div>
  `:state.groups.map(group=>`
    <section class="extension-group">
      <div class="extension-group-head">
        <div><h2>${esc(group.name)}</h2><p>${esc(group.folders.map(id=>state.folders.find(folder=>folder.id===id)?.name||id).join(', ')||'No folders assigned')}</p></div>
        <details class="action-menu row-menu"><summary>Manage group <svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 6 4 4 4-4"></path></svg></summary>
          <div class="action-menu-panel"><button type="button" data-edit-group="${group.id}">Edit group</button><button type="button" class="menu-danger" data-delete-group="${group.id}">Delete group</button></div>
        </details>
      </div>
      <div class="extension-list">${group.extensions.length?group.extensions.map(id=>{
        const extension=state.extensions.find(item=>item.id===id);
        const configured=extension?.configured||(group.configured||[]).includes(id);
        return `<div class="extension-row"><div class="extension-name"><span class="extension-mark" aria-hidden="true"><svg viewBox="0 0 20 20"><rect x="3" y="3" width="6" height="6" rx="1.5"></rect><rect x="11" y="11" width="6" height="6" rx="1.5"></rect><path d="M11 6h5M6 11v5"></path></svg></span><span>${esc(extension?.name||id)}</span></div>
          <div class="toolbar-actions">${extension?.popup?`<button type="button" class="btn-action" data-configure="${group.id}" data-ext="${id}">${configured?'Edit settings':'Configure'}</button>`:''}<button type="button" class="btn-action" data-delete-extension="${id}">Remove</button></div></div>`;
      }).join(''):'<p class="hint">No extensions in this group.</p>'}</div>
    </section>
  `).join('');
  c.querySelectorAll('[data-edit-group]').forEach(button=>button.onclick=()=>groupEditor(button.dataset.editGroup));
  c.querySelectorAll('[data-configure]').forEach(button=>button.onclick=()=>run('extensionConfigure',{id:button.dataset.ext}));
  c.querySelectorAll('[data-delete-group]').forEach(button=>button.onclick=async()=>{if(confirm('Delete this extension group?'))await run('groupDelete',{id:button.dataset.deleteGroup});});
  c.querySelectorAll('[data-delete-extension]').forEach(button=>button.onclick=async()=>{if(confirm('Remove this extension? Remove it from groups and profiles first.'))await run('extensionDelete',{id:button.dataset.deleteExtension});});
}
$('newGroupBtn').onclick=()=>groupEditor();

/* ─── SETTINGS PAGE ─── */
function renderSettings(){
  const c=$('settingsContent');if(!c)return;
  if(settingsDirty)return;
  c.innerHTML=`<div class="settings-form">
    <form id="settingsForm">
      <section class="settings-section" aria-labelledby="browsingSettingsTitle">
        <div class="settings-section-heading"><div><h2 id="browsingSettingsTitle">Browsing</h2><p>Choose how your workspace and tabs open.</p></div></div>
        <label class="setting-row"><span><strong>Tracking prevention</strong><small>Applies after restarting Pull. Strict blocks more trackers and can interrupt sign-in.</small></span><select name="tracking"><option value="balanced" ${!state.strictTracking?'selected':''}>Balanced</option><option value="strict" ${state.strictTracking?'selected':''}>Strict</option></select></label>
        <label class="setting-row"><span><strong>Tab layout</strong><small>Keep tabs beside the workspace or across the top.</small></span><select name="layout"><option value="vertical" ${state.vertical?'selected':''}>Vertical sidebar tabs</option><option value="horizontal" ${!state.vertical?'selected':''}>Horizontal top tabs</option></select></label>
        <label class="setting-row"><span><strong>When Pull starts</strong><small>Choose the workspace you return to.</small></span><select name="startupMode"><option value="restore" ${state.startupMode==='restore'?'selected':''}>Restore saved workspace tabs</option><option value="blank" ${state.startupMode==='blank'?'selected':''}>Start with an empty workspace</option><option value="home" ${state.startupMode==='home'?'selected':''}>Start blank, use homepage for new browsing</option></select></label>
        <label class="setting-row"><span><strong>Homepage</strong><small>Used when your startup preference calls for it.</small></span><input name="homePage" type="url" value="${esc(state.homePage||'https://www.google.com/')}" placeholder="https://example.com/"></label>
      </section>
      <section class="settings-section" aria-labelledby="autofillSettingsTitle">
        <div class="settings-section-heading"><div><h2 id="autofillSettingsTitle">Account autofill</h2><p>Control how assigned account details are used.</p></div></div>
        <p class="hint">Save the HTTPS sign-in address in Accounts. On that page, select the sign-in field and click the key in the toolbar. For a two-step login, click the key again on the password step.</p>
        <label class="setting-toggle"><input id="accountAutofill" type="checkbox" ${state.accountAutofill?'checked':''}><span>Allow account autofill</span></label>
      </section>
      <div class="formActions"><button type="submit" class="btn-primary">Save changes</button></div>
    </form>
    <section class="settings-section" aria-labelledby="extensionSettingsTitle">
      <div class="settings-section-heading"><div><h2 id="extensionSettingsTitle">Extensions</h2><p>Settings apply to every profile assigned that extension.</p></div></div>
      ${state.extensions.map(extension=>`<div class="settings-inline"><span>${esc(extension.name)}</span><button type="button" class="btn-secondary" data-settings-extension="${extension.id}">${extension.configured?'Edit settings':'Configure'}</button></div>`).join('')||'<p class="hint">Add an extension in the Extensions workspace first.</p>'}
    </section>
    <details class="settings-disclosure"><summary>Privacy and WebView2 <svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 6 4 4 4-4"></path></svg></summary><div>
      <p>Each profile keeps separate browsing data and uses its assigned proxy. WebView2 uses the installed browser runtime.</p>
    </div></details>
    <section class="settings-section settings-help"><div><h2>Getting started</h2><p>Review profiles, proxies and launching.</p></div><button type="button" id="showWelcome" class="btn-secondary">Show tutorial</button></section>
  </div>`;
  c.querySelectorAll('[data-settings-extension]').forEach(b=>b.onclick=()=>run('extensionConfigure',{id:b.dataset.settingsExtension}));
  $('showWelcome').onclick=showWelcome;
  const form=$('settingsForm');
  if(form){form.oninput=()=>{settingsDirty=true;};form.onchange=()=>{settingsDirty=true;};}
  if(form)form.onsubmit=async e=>{
    e.preventDefault();
    const btn=form.querySelector('[type=submit]');
    btn.disabled=true;
    const values=new FormData(form), autofill=$('accountAutofill').checked;
    settingsDirty=true;
    try{
      await call('settings',{
        vertical:values.get('layout')==='vertical',
        strictTracking:values.get('tracking')==='strict',
        
		startupMode:values.get('startupMode'),homePage:values.get('homePage')
      });
      await call('accountAutofill',{enabled:autofill});
      state=await call('state');
      settingsDirty=false;render();
      toast('Settings saved.');
    }catch(ex){toast(ex.message);}
    finally{btn.disabled=false;}
  };
}

$('extensionButtons').onclick=e=>{const b=e.target.closest('[data-extension]');if(b)run('extensionOpen',{id:b.dataset.extension});};

/* ─── INITIAL LOAD ─── */
async function loadWorkspace(){
  $('bootRetry').classList.add('hidden');$('bootMessage').textContent='Loading profiles and preferences...';
  try{state=await call('state',{},15000);$('bootStatus').classList.add('hidden');render();if(!state.profiles.length&&!localStorage.getItem('pull-welcome-4'))showWelcome();}
  catch(error){$('bootMessage').textContent='Your workspace could not load. Your saved profiles have not been changed. '+error.message;$('bootRetry').classList.remove('hidden');}
}
$('bootRetry').onclick=loadWorkspace;
loadWorkspace();
function showWelcome(){modal('Welcome to Pull',`<form><p>Start with a profile. Each profile keeps its own browsing data.</p><ol><li>Create a profile in Profiles.</li><li>Import a proxy in Proxies and assign it to a profile if needed.</li><li>Copy a link, select profiles, and choose Launch Selected.</li></ol><p class="hint">Accounts and extensions are optional. Review selected items carefully before deleting them.</p>${saveButton('Get started')}</form>`,()=>{localStorage.setItem('pull-welcome-4','1');});}
function selectedVisibleIds(){return listProfiles().filter(p=>selected.has(p.id)).map(p=>p.id);}

/* Fast access to existing workspace actions. */
(function setupCommands(){
  const dialog=$('commandDialog'), input=$('commandSearch'), results=$('commandResults');
  const section=(id)=>{run('manager');showSection(id);};
  const commands=[
    {name:'Go to Profiles', hint:'Workspace', action:()=>section('sec-profiles')},
    {name:'Go to Accounts', hint:'Workspace', action:()=>section('sec-accounts')},
    {name:'Go to Proxies', hint:'Workspace', action:()=>section('sec-proxies')},
    {name:'Go to Extensions', hint:'Workspace', action:()=>section('sec-extensions')},
    {name:'Go to Settings', hint:'Workspace', action:()=>section('sec-settings')},
    {name:'Search profiles', hint:'Profiles', action:()=>{section('sec-profiles');$('search').focus();}},
    {name:'Create profiles', hint:'Profiles', action:()=>{section('sec-profiles');$('create').click();}},
    {name:'Manage profile folders', hint:'Profiles', action:()=>{section('sec-profiles');$('manageFoldersBtn').click();}},
    {name:'Help and shortcuts', hint:'Help', action:()=>{section('sec-profiles');$('help').click();}}
  ];
  function draw(){
    const q=input.value.trim().toLowerCase();
    const allCommands=[...commands,...state.tabs.map(t=>({name:t.title||t.profileName||'New tab',hint:'Open tab',action:()=>run('activate',{id:t.id})}))];
    const matches=allCommands.filter(c=>(c.name+' '+c.hint).toLowerCase().includes(q));
    results.replaceChildren();
    if(!matches.length){const empty=document.createElement('p');empty.className='command-empty';empty.textContent='No matching commands.';results.append(empty);return;}
    matches.forEach(c=>{const b=document.createElement('button');b.type='button';b.className='command-item';const name=document.createElement('span');name.textContent=c.name;const hint=document.createElement('small');hint.textContent=c.hint;b.append(name,hint);b.onclick=()=>{dialog.close();c.action();};results.append(b);});
  }
  function open(){if(dialog.open || document.querySelector('dialog[open]'))return;input.value='';draw();dialog.showModal();input.focus();}
  $('commandButton').addEventListener('click',()=>{run('manager');open();});
  $('sidebarCommands').addEventListener('click',open);
  window.addEventListener('pull:commands',open);
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&!e.altKey&&e.key.toLowerCase()==='k'){e.preventDefault();open();}});
  input.addEventListener('input',draw);
  input.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){const first=results.querySelector('button');if(first){e.preventDefault();first.focus();}}else if(e.key==='Enter'){const first=results.querySelector('button');if(first){e.preventDefault();first.click();}}});
  results.addEventListener('keydown',e=>{const buttons=[...results.querySelectorAll('button')],i=buttons.indexOf(document.activeElement);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();if(e.key==='ArrowUp'&&i===0)input.focus();else buttons[(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus();}});
})();

$('tabs').addEventListener('keydown',e=>{
  if(e.target.closest('button')||e.ctrlKey||e.metaKey||e.altKey)return;
  const tab=e.target.closest('[role="tab"]');if(!tab)return;
  const items=[...$('tabs').querySelectorAll('[role="tab"]')],index=items.indexOf(tab);
  if(e.key==='Enter'||e.key===' '){e.preventDefault();tab.click();}
  else if(['ArrowRight','ArrowDown','ArrowLeft','ArrowUp','Home','End'].includes(e.key)){
    e.preventDefault();let next=e.key==='Home'?0:e.key==='End'?items.length-1:(index+(['ArrowRight','ArrowDown'].includes(e.key)?1:-1)+items.length)%items.length;items[next]?.focus();
  }
});

$('updateDismiss').onclick=()=>run('dismissUpdate');
$('updateInstall').onclick=()=>run('installUpdate');
